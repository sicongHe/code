from django.contrib import admin
from .models import Movie,Myrating
from import_export import resources
from import_export.admin import ImportExportModelAdmin
#admin.site.register(Movie)
#admin.site.register(Myrating)
# Register your models here.
class MovieResource(resources.ModelResource):
	
	class Meta:
		model = Movie

class MovieAdmin(ImportExportModelAdmin):
	resource_class = MovieResource

class MyratingResource(resources.ModelResource):

	class Meta:
		model = Myrating

admin.site.register(Movie,MovieAdmin)
admin.site.register(Myrating)
