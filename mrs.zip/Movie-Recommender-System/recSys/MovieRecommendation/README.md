# MovieRecommendation 

基于Python3，实现电影推荐系统，数据集是MovieLens官方数据集【见data.txt】   
   
基于用户的协同过滤算法UserCF，UserCF的思想见博客：http://blog.csdn.net/u012050154/article/details/52268057    
基于项目的协同过滤算法ItemCF  

关于推荐系统的介绍见博客：http://blog.csdn.net/u012050154/article/details/52267712
